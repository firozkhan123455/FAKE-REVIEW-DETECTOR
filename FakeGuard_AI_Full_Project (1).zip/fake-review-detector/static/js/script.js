document.addEventListener("DOMContentLoaded", () => {
  const picker = document.getElementById("ratingPicker");
  const ratingInput = document.getElementById("rating");
  const reviewText = document.getElementById("reviewText");
  const wordCount = document.getElementById("wordCount");
  const form = document.getElementById("reviewForm");
  const analyzeBtn = document.getElementById("analyzeBtn");

  if (picker && ratingInput) {
    const stars = Array.from(picker.querySelectorAll(".star-btn"));
    const paint = (rating) => {
      stars.forEach((star, index) => {
        star.classList.toggle("active", index < rating);
      });
    };
    paint(Number(ratingInput.value || 5));

    stars.forEach((star) => {
      star.addEventListener("click", () => {
        const value = Number(star.dataset.rating);
        ratingInput.value = value;
        paint(value);
      });
    });
  }

  if (reviewText && wordCount) {
    const updateCount = () => {
      const text = reviewText.value.trim();
      wordCount.textContent = text ? text.split(/\s+/).length : 0;
    };
    reviewText.addEventListener("input", updateCount);
    updateCount();
  }

  if (form && analyzeBtn) {
    form.addEventListener("submit", () => {
      analyzeBtn.disabled = true;
      analyzeBtn.textContent = "Analyzing...";
    });
  }
});
