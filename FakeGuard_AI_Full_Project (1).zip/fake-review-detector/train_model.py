import os
import re
import joblib
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATASET_PATH = os.path.join(BASE_DIR, "reviews.csv")
MODEL_PATH = os.path.join(BASE_DIR, "model.pkl")

def clean_text(text: str) -> str:
    text = str(text).lower()
    text = re.sub(r"http\S+|www\.\S+", " ", text)
    text = re.sub(r"[^a-z0-9\s!?']", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text

def train_model():
    df = pd.read_csv(DATASET_PATH)
    required = {"review_text", "label"}
    if not required.issubset(df.columns):
        raise ValueError("reviews.csv must contain review_text and label columns")

    df = df.dropna(subset=["review_text", "label"]).copy()
    df["review_text"] = df["review_text"].astype(str).apply(clean_text)
    df["label"] = df["label"].astype(int)

    X_train, X_test, y_train, y_test = train_test_split(
        df["review_text"],
        df["label"],
        test_size=0.25,
        random_state=42,
        stratify=df["label"]
    )

    pipeline = Pipeline([
        ("tfidf", TfidfVectorizer(
            ngram_range=(1, 2),
            min_df=1,
            max_df=0.98,
            sublinear_tf=True
        )),
        ("clf", LogisticRegression(
            max_iter=1500,
            class_weight="balanced",
            random_state=42
        ))
    ])

    pipeline.fit(X_train, y_train)

    preds = pipeline.predict(X_test)
    accuracy = accuracy_score(y_test, preds)
    print(f"Model accuracy on sample holdout data: {accuracy:.3f}")
    print(classification_report(y_test, preds, digits=3))

    joblib.dump(pipeline, MODEL_PATH)
    print(f"Saved model to {MODEL_PATH}")
    return pipeline

if __name__ == "__main__":
    train_model()
