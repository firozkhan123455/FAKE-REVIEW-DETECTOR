# FakeGuard AI — Fake Product Review Detection

A complete college project that classifies product reviews as **Likely Genuine** or **Likely Fake / Suspicious** using:

- Python
- Flask
- HTML, CSS, JavaScript
- Bootstrap
- scikit-learn
- TF-IDF Vectorizer
- Logistic Regression
- SQLite
- Chart.js

## Main Features

- Review analysis form
- Product name, category and star rating input
- Fake and genuine probability
- Confidence level
- SQLite review history
- Dashboard statistics
- Genuine vs suspicious chart
- Category chart
- Delete individual history items
- Clear all history
- JSON API endpoint at `/api/analyze`
- Automatic model training on first run

## Project Flow

Review Input  
→ Text Cleaning  
→ TF-IDF Vectorization  
→ Logistic Regression  
→ Probability Prediction  
→ Flask Result Page  
→ SQLite History

## Folder Structure

```text
fake-review-detector/
├── app.py
├── train_model.py
├── reviews.csv
├── requirements.txt
├── README.md
├── templates/
│   ├── base.html
│   ├── index.html
│   ├── detector.html
│   ├── result.html
│   ├── dashboard.html
│   └── about.html
└── static/
    ├── css/
    │   └── style.css
    └── js/
        └── script.js
```

`model.pkl` and `database.db` are created automatically.

## How to Run

### 1. Open the project in VS Code

Open the `fake-review-detector` folder.

### 2. Open Terminal

In VS Code:

```text
Terminal → New Terminal
```

### 3. Create a virtual environment (recommended)

Windows:

```bash
python -m venv venv
venv\Scripts\activate
```

### 4. Install dependencies

```bash
pip install -r requirements.txt
```

### 5. Train the model

```bash
python train_model.py
```

This creates:

```text
model.pkl
```

You can skip this step because `app.py` also trains automatically when the model is missing.

### 6. Start the website

```bash
python app.py
```

### 7. Open in browser

```text
http://127.0.0.1:5000
```

## API Example

POST:

```text
/api/analyze
```

JSON body:

```json
{
  "review_text": "Amazing product! Everyone must buy this right now!"
}
```

## Important Academic Note

This project detects patterns learned from labelled review text. It does **not** prove that a real-world reviewer is fraudulent. For a production system, use a larger verified dataset and additional signals such as verified-purchase status, reviewer behavior, review timing and product metadata.
