import os
import re
import sqlite3
from datetime import datetime
from collections import Counter

import joblib
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "database.db")
MODEL_PATH = os.path.join(BASE_DIR, "model.pkl")

app = Flask(__name__)
app.secret_key = "fakeguard-college-project-secret"

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS reviews (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            product_name TEXT NOT NULL,
            category TEXT,
            rating INTEGER,
            review_text TEXT NOT NULL,
            prediction TEXT NOT NULL,
            fake_probability REAL NOT NULL,
            genuine_probability REAL NOT NULL,
            confidence TEXT NOT NULL,
            created_at TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()

def clean_text(text: str) -> str:
    text = str(text).lower()
    text = re.sub(r"http\S+|www\.\S+", " ", text)
    text = re.sub(r"[^a-z0-9\s!?']", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text

def ensure_model():
    if not os.path.exists(MODEL_PATH):
        from train_model import train_model
        train_model()
    return joblib.load(MODEL_PATH)

model = None

def get_model():
    global model
    if model is None:
        model = ensure_model()
    return model

def confidence_label(probability: float) -> str:
    certainty = abs(probability - 0.5) * 2
    if certainty >= 0.70:
        return "High"
    elif certainty >= 0.35:
        return "Medium"
    return "Low"

def heuristic_adjustment(review: str, ml_fake_prob: float) -> float:
    text = review.strip()
    lower = text.lower()
    score = ml_fake_prob

    excessive_caps = sum(1 for c in text if c.isupper()) / max(len(text), 1)
    exclamations = text.count("!")
    promo_phrases = [
        "buy now", "must buy", "best ever", "100% recommended",
        "life changing", "amazing product", "everyone should buy",
        "five stars", "perfect product", "highly recommend"
    ]
    repeated = bool(re.search(r"\b(\w+)(?:\s+\1){2,}\b", lower))

    if excessive_caps > 0.35 and len(text) > 20:
        score += 0.08
    if exclamations >= 4:
        score += 0.07
    if sum(p in lower for p in promo_phrases) >= 2:
        score += 0.10
    if repeated:
        score += 0.05
    if len(text.split()) >= 12 and any(x in lower for x in ["however", "but", "although", "after", "because"]):
        score -= 0.04

    return max(0.01, min(0.99, score))

def analyze_review(review_text: str):
    cleaned = clean_text(review_text)
    pipeline = get_model()
    probabilities = pipeline.predict_proba([cleaned])[0]
    classes = list(pipeline.named_steps["clf"].classes_)
    fake_index = classes.index(1)
    ml_fake = float(probabilities[fake_index])

    fake_prob = heuristic_adjustment(review_text, ml_fake)
    genuine_prob = 1 - fake_prob
    prediction = "Likely Fake / Suspicious" if fake_prob >= 0.50 else "Likely Genuine"
    confidence = confidence_label(fake_prob)

    return {
        "prediction": prediction,
        "fake_probability": round(fake_prob * 100, 1),
        "genuine_probability": round(genuine_prob * 100, 1),
        "confidence": confidence
    }

@app.route("/")
def home():
    conn = get_db()
    total = conn.execute("SELECT COUNT(*) FROM reviews").fetchone()[0]
    fake = conn.execute(
        "SELECT COUNT(*) FROM reviews WHERE prediction LIKE 'Likely Fake%'"
    ).fetchone()[0]
    genuine = total - fake
    conn.close()
    return render_template("index.html", total=total, fake=fake, genuine=genuine)

@app.route("/detect", methods=["GET", "POST"])
def detect():
    if request.method == "POST":
        product_name = request.form.get("product_name", "").strip()
        category = request.form.get("category", "").strip()
        rating_raw = request.form.get("rating", "0").strip()
        review_text = request.form.get("review_text", "").strip()

        if not product_name or not review_text:
            flash("Please enter both a product name and a review.", "danger")
            return redirect(url_for("detect"))

        if len(review_text.split()) < 3:
            flash("Please enter a slightly longer review for better analysis.", "warning")
            return redirect(url_for("detect"))

        try:
            rating = int(rating_raw)
        except ValueError:
            rating = 0

        result = analyze_review(review_text)

        conn = get_db()
        cursor = conn.execute("""
            INSERT INTO reviews (
                product_name, category, rating, review_text, prediction,
                fake_probability, genuine_probability, confidence, created_at
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            product_name, category, rating, review_text,
            result["prediction"], result["fake_probability"],
            result["genuine_probability"], result["confidence"],
            datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        ))
        review_id = cursor.lastrowid
        conn.commit()
        conn.close()

        return redirect(url_for("result", review_id=review_id))

    return render_template("detector.html")

@app.route("/result/<int:review_id>")
def result(review_id):
    conn = get_db()
    review = conn.execute("SELECT * FROM reviews WHERE id = ?", (review_id,)).fetchone()
    conn.close()

    if review is None:
        flash("Review result not found.", "danger")
        return redirect(url_for("detect"))

    return render_template("result.html", review=review)

@app.route("/dashboard")
def dashboard():
    conn = get_db()
    reviews = conn.execute("SELECT * FROM reviews ORDER BY id DESC").fetchall()
    conn.close()

    total = len(reviews)
    fake = sum(1 for r in reviews if r["prediction"].startswith("Likely Fake"))
    genuine = total - fake
    avg_conf = round(
        sum(max(r["fake_probability"], r["genuine_probability"]) for r in reviews) / total, 1
    ) if total else 0

    categories = Counter((r["category"] or "Other") for r in reviews)
    chart_labels = list(categories.keys())
    chart_values = list(categories.values())

    return render_template(
        "dashboard.html",
        reviews=reviews,
        total=total,
        fake=fake,
        genuine=genuine,
        avg_conf=avg_conf,
        chart_labels=chart_labels,
        chart_values=chart_values
    )

@app.route("/history/delete/<int:review_id>", methods=["POST"])
def delete_review(review_id):
    conn = get_db()
    conn.execute("DELETE FROM reviews WHERE id = ?", (review_id,))
    conn.commit()
    conn.close()
    flash("Review removed from history.", "success")
    return redirect(url_for("dashboard"))

@app.route("/history/clear", methods=["POST"])
def clear_history():
    conn = get_db()
    conn.execute("DELETE FROM reviews")
    conn.commit()
    conn.close()
    flash("History cleared.", "success")
    return redirect(url_for("dashboard"))

@app.route("/about")
def about():
    return render_template("about.html")

@app.route("/api/analyze", methods=["POST"])
def api_analyze():
    data = request.get_json(silent=True) or {}
    review_text = str(data.get("review_text", "")).strip()
    if len(review_text.split()) < 3:
        return jsonify({"error": "review_text must contain at least 3 words"}), 400
    return jsonify(analyze_review(review_text))

if __name__ == "__main__":
    init_db()
    get_model()
    app.run(debug=True)
else:
    init_db()
